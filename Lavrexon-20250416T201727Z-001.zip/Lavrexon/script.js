const primaryHeader = document.querySelector(".primary-header");
const navToggle = document.querySelector(".mobile-nav-toggle");
const primaryNav = document.querySelector(".primary-navigation");
const body = document.body;
body.classList.toggle("no-scroll", primaryNav.hasAttribute('data-visible'));

navToggle.addEventListener("click", () => {
    const isOpened = primaryNav.hasAttribute("data-visible");
    navToggle.setAttribute("aria-expanded", !isOpened);
    primaryNav.toggleAttribute("data-visible");
    primaryHeader.toggleAttribute("data-overlay");
    body.classList.toggle("no-scroll", !isOpened);
});


const navLinks = document.querySelectorAll(".nav-list a");
navLinks.forEach(link => {
    link.addEventListener("click", () => {
        primaryNav.removeAttribute("data-visible");
        navToggle.setAttribute("aria-expanded", "false");
        body.classList.remove("no-scroll");
    });
});


document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();  
    
    const form = event.target;
    const successMessage = document.getElementById('success-message');

    const formData = new FormData(form);

    fetch(form.action, {
        method: form.method,
        body: formData
    })
    .then(response => {
        if (response.ok) {

            successMessage.style.display = 'block';
            form.reset();  
        } else {
            throw new Error('Form submission failed');
        }
    })
    .catch(error => {
        document.getElementById('error-message').style.display = 'block';
    });
});




